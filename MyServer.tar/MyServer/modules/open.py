# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/5/2018
# Powered By :- Aex Software's

import os
import sys
from time import sleep
from Mylogo import Mylogo
from ux import Ux
from ux import ex
from ope import ssh

def opens():
 while True:
	os.system("python2 ~/.MyServer/modules/.srvr.aex")
	Mylogo()
	dn = raw_input('''\n\033[1;33m Enter your subdomain name (\033[01;32mex Myweb\033[01;33m) :- \033[01;36m''')
	portl = raw_input('''\033[1;33m Enter your localhost port (\033[01;32mex 8080\033[01;33m) :- \033[01;36m''')
	port = raw_input('''\033[1;33m Enter your port (\033[01;32mex 80\033[01;33m) :- \033[01;36m''')
	os.system("python2 ~/.MyServer/modules/.srvr.aex")
	Mylogo()
	print("\n\033[01;33mStarting Server ......\033[00m\n")
	if os.path.exists("/usr/bin/ssh"):
		os.system("ssh -R "+port+":localhost:"+portl+" "+dn+"@localhost.run")
		print("\007\033[01;31m unfortunately server stopped.\n\033[00m")
		ex()
	elif os.path.exists("/data/data/com.termux/files/usr/bin/ssh"):
		os.system("ssh -R "+port+":localhost:"+portl+" "+dn+"@localhost.run")
		print("\007\033[01;31m unfortunately server stopped.\n\033[00m")
		ex()
	else:
		ssh()
		if os.path.exists("/data/data/com.termux/files/usr/bin/ssh"):
		    opens()
		elif os.path.exists("/usr/bin/ssh"):
		    opens()
		else:
		    os.system("myserver")
		    ex()


def open():
	opens()
