# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 23/5/2018
# Powered By :- Aex Software's

import os
import sys
from Mylogo import Mylogo

def ab():
  os.system("clear")
  Mylogo()
  print('''
      \033[1;36m Tool Name   :-     \033[0;33mMyServer
      \033[1;36m Developer   :-     \033[0;33mRajkumar Dusad
      \033[1;36m Powered By  :-     \033[0;33mAex Software's

\033[1;33m MyServer :- \033[0;32mMyServer is your own localhost
 server. you can setup PHP, Apache web servers
 on your android or linux like Ubuntu etc.
 it is Developed for android Termux or GNURoot.
 You can setup your localhost server and access
 from internet. you can host your website.\033[1;m
''')