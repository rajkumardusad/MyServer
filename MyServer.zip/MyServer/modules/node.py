# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/5/2018
# Powered By :- Aex Software's

import os
import sys
from ux import Ux
from time import sleep

def notL():
	print("\033[1;31m Error \'localtunnel\' \033[01;32mCan not install in termux.\033[00m")
	sleep(2)

def Ter():
	if os.path.exists("/data/data/com.termux/files/usr/bin/pkg"):
		notL()
	else:
		notL()

def Deb():
	if os.path.exists("/usr/bin/apt"):
		os.system("sudo apt-get update")
		os.system("sudo apt-get upgrade -y")
		os.system("sudo apt-get install curl python-software-properties -y")
		os.system("sudo curl -sL https://deb.nodesource.com/setup_10.x | sudo bash -")
		os.system("sudo apt-get install nodejs -y")
		os.system("sudo apt-get install npm -y")
		os.system("sudo npm install -g localtunnel")
	else:
		Ter()

def Deb1():
	if os.path.exists("/usr/bin/apt"):
		os.system("apt-get install sudo -y")
		os.system("apt-get update")
		os.system("apt-get upgrade -y")
		os.system("apt-get install curl python-software-properties -y")
		os.system("curl -sL https://deb.nodesource.com/setup_10.x | sudo bash -")
		os.system("apt-get install nodejs -y")
		os.system("apt-get install npm -y")
		os.system("npm install -g localtunnel")
	else:
		Ter()

def Debian():
	if os.path.exists("/usr/lib/sudo"):
		Deb()
	else:
		Deb1()

def Ubu():
	if os.path.exists("/usr/bin/apt"):
		os.system("sudo apt-get update")
		os.system("sudo apt-get upgrade -y")
		os.system("sudo apt-get install nodejs -y")
		os.system("sudo apt-get install npm -y")
		os.system("sudo npm install -g localtunnel")
	else:
		Debian()

def CHK():
	if os.path.exists("/usr/lib/sudo"):
		Ubu()
	else:
		Deb()

def js():
	CHK()
