# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 23/5/2018
# Powered By :- Aex Software's

import os
import sys
from time import sleep
from logo import logo
from ux import Ux
from ux import ex,exit
from local import local
from open import open
from local import local
from Abu import ab
from Mylogo import Mylogo
from ope import ssh
from node import js

class know(object):
    def About(self):
	Ux()
	ab()
	while True:
		back = raw_input(''' \033[0;33m\033[4;mMyServer\033[00m\033[01;31m > \033[1;36m''')
		while back == "":
			menu()
		while back == "back":
			menu()
		while back == "Back":
			menu()
		while back == "0":
			menu()
		else:
			print("\n \033[01;31m\007Command not found :\033[01;32m \'"+back+"\'")
			sleep(1)
			self.About()

class Un(object):
    def Uni(self):
	while True:
		ask = raw_input('''\n\033[1;33m Do you want to uninstall MyServer [Y/n] >> \033[1;36m''')
		while ask == "n":
			OPT()
		while ask == "N":
			OPT()
		while ask == "Y":
			os.system("rm -rf /data/data/com.termux/files/usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("rm -rf /usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("sudo rm -rf /usr/bin/myserver && sudo rm -rf ~/.MyServer")
			exit()
		while ask == "y":
			os.system("rm -rf /data/data/com.termux/files/usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("rm -rf /usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("sudo rm -rf /usr/bin/myserver && sudo rm -rf ~/.MyServer")
			exit()
		else:
			print("\n \033[01;31m\007Command not found :\033[01;32m \'"+ask+"\'")
			sleep(1)
			self.Uni()

class Upd(object):
    def U(self):
	while True:
		Mylogo()
		askv = raw_input('''\n\033[1;33m Do you want to Update MyServer [Y/n] >> \033[1;36m''')
		while askv == "n":
			OPT()
		while askv == "N":
			OPT()
		while askv == "Y":
			os.system("rm -rf /data/data/com.termux/files/usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("rm -rf /usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("sudo rm -rf /usr/bin/myserver && sudo rm -rf ~/.MyServer")
			os.system("sudo apt-get install git -y")
			os.system("apt-get install git -y")
			os.system("pkg install git -y")
			os.system("sudo cd ~/ && git clone https://github.com/Rajkumrdusad/MyServer.git")
			os.system("cd ~/ && git clone https://github.com/Rajkumrdusad/MyServer.git")
			os.system("sudo cd ~/MyServer && sh install")
			os.system("cd ~/MyServer && sh install")
			os.system("clear")
			Mylogo()
			sleep(1)
			os.system("clear")
			os.system("myserver")
			sys.exit()
		while askv == "y":
			os.system("rm -rf /data/data/com.termux/files/usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("rm -rf /usr/bin/myserver && rm -rf ~/.MyServer")
			os.system("sudo rm -rf /usr/bin/myserver && sudo rm -rf ~/.MyServer")
			os.system("sudo apt-get install git -y")
			os.system("apt-get install git -y")
			os.system("pkg install git -y")
			os.system("sudo cd ~/ && git clone https://github.com/Rajkumrdusad/MyServer.git")
			os.system("cd ~/ && git clone https://github.com/Rajkumrdusad/MyServer.git")
			os.system("sudo cd ~/MyServer && sh install")
			os.system("cd ~/MyServer && sh install")
			os.system("clear")
			Mylogo()
			sleep(1)
			os.system("clear")
			os.system("myserver")
			sys.exit()
		else:
			print("\n \033[01;31m\007Command not found :\033[01;32m \'"+askv+"\'")
			sleep(1)
			self.U()

def php():
  os.system("python2 ~/.MyServer/modules/.srvr.aex")
  Mylogo()
  if os.path.exists("/usr/bin/php"):
    phps()
  elif os.path.exists("/data/data/com.termux/files/usr/bin/php"):
    phps()
  else:
    print("\033[01;31m Sorry we can't install PHP in your system.")
    sleep(3)
    OPT()

def phps():
  getpat=raw_input("\033[01;33m Enter your web path (\033[01;36mex /sdcard/www\033[01;33m) :- \033[01;36m")
  getp=raw_input("\033[01;33m Enter your port (\033[01;36mex 8080\033[01;33m) :- \033[01;36m")
  host=raw_input("\033[01;33m Enter your localhost ip (\033[01;36mex localhost OR 127.0.0.1\033[01;33m) :- \033[01;36m")
  os.system("python2 ~/.MyServer/modules/.srvr.aex")
  Mylogo()
  print("\n\033[01;33mStarting Server ......\033[00m\n")
  hostn=host
  pat=getpat
  port=getp
  os.system("php -S "+hostn+":"+port+" -t "+pat)
  print("\033[01;31m unfortunately server stopped\n\033[00m")
  ex()

def OPT():
 Ux()
 logo()
 while True:

	Tool = raw_input(''' \033[0;33m\033[4;mMyServer\033[00m\033[01;31m > \033[1;36m''')
	while Tool == "1":
		if os.path.exists("/data/data/com.termux/files/usr/bin/php"):
		    php()
		elif os.path.exists("/usr/bin/php"):
		    php()
		else:
		    if os.path.exists("/usr/lib/sudo"):
		        os.system("sudo apt-get install php -y")
		        os.system("sudo apt-get install php5 -y")
		        php()
		    elif os.path.exists("/data/data/com.termux/files/usr/bin/pkg"):
		        os.system("pkg install php -y")
		        php()
		    else:
		        os.system("apt-get install php5 -y")
		        php()
		OPT()

	while Tool == "2":
		if os.path.exists("/data/data/com.termux/files/usr/bin/ssh"):
		    open()
		elif os.path.exists("/usr/bin/lt"):
		    local()
		else:
		    if os.path.exists("/usr/lib/sudo"):
		        js()
		        local()
		    elif os.path.exists("/data/data/com.termux/files/usr/bin/pkg"):
		        ssh()
		        open()

	while Tool == "3":
		os.system("python2 ~/.MyServer/modules/MServer.py")
		ex()

	while Tool == "4":
		os.system("python2 ~/.MyServer/modules/Mhost.py")
		ex()

	while Tool == "5":
		Upd().U()
		ex()


	while Tool == "6":
		know().About()

	while Tool == "Uninstall MyServer":
		Un().Uni()
		sleep(1)
		ex()

	while Tool == "uninstall myserver":
		Un().Uni()
		sleep(1)
		ex()

	while Tool == "rm -T":
		Un().Uni()
		sleep(1)
		ex()

	while Tool == "exit":
		exit()

	while Tool == "x":
		Toolo = raw_input("\n\033[1;32m Do you want to Exit ? [Y/n] >>  \033[1;m")
		if Toolo == "N":
			OPT()
		elif Toolo == "n":
			OPT()
		elif Toolo == "Y":
			exit()

		elif Toolo == "y":
			exit()
		else:
			print("\n \033[01;31m\007Command not found :\033[01;32m \'"+Toolo+"\'")

	else:
		print("\n \033[01;31m\007Command not found :\033[01;32m \'"+Tool+"\'")
		sleep(1)
		OPT()


def menu():
	OPT()
