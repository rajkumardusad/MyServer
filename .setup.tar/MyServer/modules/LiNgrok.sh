#!/data/data/com.termux/files/usr/bin/bash
file=ngrok
pkg install tar -y
apt-get install tar -y
sudo apt-get install tar -y
if [ -f "/bin/$file" ]; then
    first=1
    echo "skipping downloading"
fi
if [ -f "/data/data/com.termux/files/usr/bin/$file" ]; then
    first=1
    echo "skipping downloading"
fi
if [ "$first" != 1 ];then
    if [ ! -f "/usr/bin/sudo" ]; then
        echo "downloading Ngrok"
        if [ "$(dpkg --print-architecture)" = "aarch64" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm64.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "arm" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "i686" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "i386" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-386.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "armhf" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "armv7" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "arm64" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm64.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "armv8" ];then
            cd ~/ && wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm64.tgz -O ngrok.tar.gz
        else
            echo "unknown architecture"
            exit 1
        fi
    fi
    if [ -f "/usr/bin/sudo" ]; then
        echo "downloading Ngrok"
        if [ "$(dpkg --print-architecture)" = "aarch64" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm64.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "arm" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "i686" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "i386" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-386.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "armhf" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "armv7" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "arm64" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm64.tgz -O ngrok.tar.gz
        elif [ "$(dpkg --print-architecture)" = "armv8" ];then
            cd ~/ && sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm64.tgz -O ngrok.tar.gz
        else
            echo "unknown architecture"
            exit 1
        fi
    fi
fi
cd ~/ && tar -xvzf ngrok.tar.gz
cd ~/ && rm -rf ngrok.tar.gz
if [ -d "/bin/" ]; then
    mv -v ~/ngrok /bin/
    chmod +x /bin/ngrok
fi
if [ -f "/usr/lib/sudo" ]; then
    sudo mv -v ~/ngrok /bin/
    sudo chmod +x /bin/ngrok
    cd ~/ && sudo rm -rf ngrok.tar.gz
fi
if [ -d "/data/data/com.termux/files/usr/bin/" ]; then
    mv -v ~/ngrok /data/data/com.termux/files/usr/bin/
    chmod +x /data/data/com.termux/files/usr/bin/bin/ngrok
fi
