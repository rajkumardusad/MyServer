# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/5/2018
# Powered By :- Aex Software's

import sys
import os
from time import sleep
from ux import Ux
from ux import ex
from ux import exit
from mh import logo
from Mylogo import Mylogo
from open import open
from local import local


def insng():
  if os.path.exists("/usr/bin/apt"):
    print("\n\n\033[01;32mInstalling ngrok ....\n")
    os.system("sh ~/.MyServer/modules/LiNgrok.sh")
    if os.path.exists("/bin/ngrok"):
      token()
    else:
      Mylogo()
      print("\033[01;31m Sorry we can not install ngrok in your system.")
      print("\n\033[01;32m Please download ngrok and extract zip or tar file into /bin directory.\033[00m")
      ex()
  else:
    print("\n\n\033[01;32mInstalling ngrok ....\n")
    os.system("sh ~/.MyServer/modules/LiNgrok.sh")
    if os.path.exists("/data/data/com.termux/files/usr/bin/ngrok"):
      token()
    else:
      Mylogo()
      print("\033[01;31m Sorry we can not install ngrok in your system.")
      print("\n\033[01;32m Please download ngrok and extract zip or tar file into /bin directory.\033[00m")
      ex()

def token():
  os.system("python2 ~/.MyServer/modules/.srvr.aex")
  Mylogo()
  auth=raw_input("\033[01;33m You have ngrok authtoken [Y/n] :- \033[01;36m")
  if auth=="y":
    getauth=raw_input("\033[01;33m Enter your ngrok authtoken :- \033[01;36m")
    os.system("ngrok authtoken "+getauth)
    ngrk()
  elif auth=="Y":
    getauth=raw_input("\033[01;33m Enter your ngrok authtoken :- \033[01;36m")
    os.system("ngrok authtoken "+getauth)
    ngrk()
  else:
    ngrk()

def ngrk():
  acp=raw_input("\033[01;33m You have paid ngrok account [Y/n] :- \033[01;36m")
  if acp=="Y":
    paid()
  elif acp=="y":
    paid()
  else:
    free()

def free():
    getp=raw_input("\033[01;33m Enter your port (\033[01;32mex 8080\033[01;33m) :- \033[01;36m")
    port=getp
    os.system("ngrok http "+port)
    print("\033[01;31m unfortunately server stopped\n\033[00m")
    ex()

def paid():
    getsub=raw_input("\033[01;33m Enter your subdomain name (\033[01;32mex myweb\033[01;33m) :- \033[01;36m")
    getp=raw_input("\033[01;33m Enter your port (\033[01;32mex 8080\033[01;33m) :- \033[01;36m")
    port=getp
    os.system("ngrok http -subdomain="+getsub+" "+port)
    print("\033[01;31m unfortunately server stopped\n\033[00m")
    ex()

def OPT():
 Ux()
 logo()
 while True:

	Tool = raw_input(''' \033[0;33m\033[4;mMyServer\033[00m\033[01;31m > \033[1;36m''')
	while Tool == "1":
		if os.path.exists("/data/data/com.termux/files/usr/bin/ssh"):
		    open()
		else:
		    local()

	while Tool == "2":
		open()

	while Tool == "3":
		if os.path.exists("/data/data/com.termux/files/usr/bin/ngrok"):
		    token()
		elif os.path.exists("/bin/ngrok"):
		    token()
		else:
		    insng()

	while Tool == "4":
		local()

	while Tool == "0":
		os.system("myserver")
		ex()

	else:
		print("\n \033[01;31m\007Command not found :\033[01;32m \'"+Tool+"\'")
		sleep(0.7)
		OPT()

def MyServer():
  try:
	OPT()

  except KeyboardInterrupt:
	exit()
MyServer()
