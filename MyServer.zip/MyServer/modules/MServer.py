# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/5/2018
# Powered By :- Aex Software's

import sys
import os
from time import sleep
from ux import Ux
from ux import ex
from ux import exit
from ml import logo
from Mylogo import Mylogo

class start(object):
    def localhost(self):
	       os.system("python2 ~/.MyServer/modules/.srvr.aex")
	       Mylogo()
	       gp=raw_input("\n\033[01;33m Enter website path (\033[01;36mex /sdcard/www\033[01;33m) :- \033[01;36m")
	       port=raw_input("\033[01;33m Enter your port (\033[01;36mex 8080\033[01;33m) :- \033[01;36m")
	       os.system("python2 ~/.MyServer/modules/.srvr.aex")
	       Mylogo()
	       print("\n \033[01;33mYour Server URL is :- \033[01;36mhttp://localhost:"+port+"/ \n http://127.0.0.1:"+port+"/\033[00m\n")
	       os.system("cd "+gp+" && python2 -m SimpleHTTPServer "+port)
	       print("\033[01;31m unfortunately server stopped\n\033[00m")
	       ex()

def apa():
  os.system("python2 ~/.MyServer/modules/.srvr.aex")
  Mylogo()
  if os.path.exists("/data/data/com.termux/files/usr/bin/apachectl"):
    os.system("apachectl")
    sleep(4)
  elif os.path.exists("/usr/sbin/apachectl"):
    os.system("apachectl start")
    sleep(4)
  elif os.path.exists("/usr/sbin/apache2"):
    os.system("apache2 start")
    sleep(4)
  else:
    print("\033[01;31m Error Apache Not installed.")
  sleep(4)

def php():
  os.system("python2 ~/.MyServer/modules/.srvr.aex")
  Mylogo()
  if os.path.exists("/usr/bin/php"):
    phps()
  elif os.path.exists("/data/data/com.termux/files/usr/bin/php"):
    phps()
  else:
    print("\033[01;31m Sorry we can't install PHP in your system.")
    sleep(3)
    OPT()

def phps():
  getpat=raw_input("\033[01;33m Enter your web path (\033[01;36mex /sdcard/www\033[01;33m) :- \033[01;36m")
  getp=raw_input("\033[01;33m Enter your port (\033[01;36mex 8080\033[01;33m) :- \033[01;36m")
  host=raw_input("\033[01;33m Enter your localhost ip (\033[01;36mex localhost OR 127.0.0.1\033[01;33m) :- \033[01;36m")
  os.system("python2 ~/.MyServer/modules/.srvr.aex")
  Mylogo()
  print("\n\033[01;33mStarting Server ......\033[00m\n")
  hostn=host
  pat=getpat
  port=getp
  os.system("php -S "+hostn+":"+port+" -t "+pat)
  print("\033[01;31m unfortunately server stopped\n\033[00m")
  ex()

def OPT():
 Ux()
 logo()
 while True:

	Tool = raw_input(''' \033[0;33m\033[4;mMyServer\033[00m\033[01;31m > \033[1;36m''')
	while Tool == "1":
		if os.path.exists("/data/data/com.termux/files/usr/bin/php"):
		    php()
		elif os.path.exists("/usr/bin/php"):
		    php()
		else:
		    if os.path.exists("/usr/lib/sudo"):
		        os.system("sudo apt-get install php5 -y")
		        php()
		    elif os.path.exists("/data/data/com.termux/files/usr/bin/pkg"):
		        os.system("pkg install php -y")
		        php()
		    else:
		        os.system("apt-get install php5 -y")
		        php()
		OPT()

	while Tool == "2":
		start().localhost()
		ex()

	while Tool == "3":
		if os.path.exists("/data/data/com.termux/files/usr/bin/apachectl"):
		    apa()
		elif os.path.exists("/usr/sbin/apache2"):
		    apa()
		else:
		    if os.path.exists("/usr/lib/sudo"):
		        os.system("sudo apt-get install apache2 -y")
		        apa()
		    elif os.path.exists("/data/data/com.termux/files/usr/bin/pkg"):
		        os.system("pkg install apache2 -y")
		        apa()
		    else:
		        os.system("apt-get install apache2 -y")
		        apa()
		OPT()

	while Tool == "0":
		os.system("myserver")
		ex()

	else:
		print("\n \033[01;31m\007Command not found :\033[01;32m \'"+Tool+"\'")
		sleep(0.7)
		OPT()

def MyServer():
  try:
	OPT()

  except KeyboardInterrupt:
	exit()
MyServer()
