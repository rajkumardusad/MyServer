# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/5/2017
# Powered By :- Aex Software's

import os
import sys
from time import sleep
from system import *

def Ux():
 Ux = os.system("clear")

def ex():
 ex = sys.exit()

def exit():
 sleep(1)
 print("\n \007\033[01;31mExiting .........")
 sleep(1)
 print(" \007\033[01;32mG00D By .......... :)")
 sleep(1)
 print("\033[00m")
 sys.exit()
