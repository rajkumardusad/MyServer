# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/5/2018
# Powered By :- Aex Software's

import sys
import os
from modules.ux import exit
from time import sleep
from modules.menu import menu

def MyServer():
  try:
	menu()

  except KeyboardInterrupt:
	exit()
MyServer()