# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/5/2018
# Powered By :- Aex Software's

import sys
import os
from time import sleep
from system import *
from ux import *
from logo import *

class MySQL(object):
  def chmys(self):
    if os.path.exists(bpath+"mysql"):
      os.system("python2 ~/.MyServer/modules/.srvr.aex")
      self.mysqls()
    else:
      Mylogo()
      print("\033[01;31m Sorry we can't install \033[01;32mMySQL \033[01;31min your "+system+".")
      sleep(3)

  def mysqls(self):
    Mylogo()
    usrnm=raw_input("\033[01;33m Enter your MySQL username :- \033[01;36m")
    if usrnm=="":
      print("\n\033[01;31m\007 Error Please enter your \033[01;33mMySQL username\033[01;31m !!\n")
      self.mysqls()
    os.system("python2 ~/.MyServer/modules/.srvr.aex")
    Mylogo()
    print("\n\033[01;33mStarting Server ......\033[00m\n")
    if os.path.exists("/usr/lib/sudo"):
      os.system("sudo service mysql start")
      os.system("sudo mysql -u "+usrnm+" -p")
      print("\033[01;31m unfortunately server stopped\n\033[00m")
    elif system=="ubuntu":
      os.system("sudo systemctl mysql start")
      os.system("sudo mysql -u "+usrnm+" -p")
      print("\033[01;31m unfortunately server stopped\n\033[00m")
    else:
      os.system("service mysql start")
      os.system("mysql -u "+usrnm+" -p")
      print("\033[01;31m unfortunately server stopped\n\033[00m")
    ex()

  def inmys(self):
    if os.path.exists(bpath+"mysql"):
      os.system("python2 ~/.MyServer/modules/.srvr.aex")
      self.mysqls()
    else:
      Mylogo()
      os.system(pac+" update")
      os.system(pac+" install mysql-server -y")
      os.system("mysql_secure_installation")
      self.chmys()
  
def Mys():
  MySQL().inmys()